package Assignment8;

public class calculation1 {
    int total (int x, int y)
    {
        return x+y;
    }
    int total(int x,int y, int z)
    {
        return x+y+z;
    }
    double total(double x,double y)
    {
        return x+y;
    }
    double total(double x,double y, double z)
    {
        return x+y+z;
    }
}


