package Assignment12;

public class arrayexception {

}
