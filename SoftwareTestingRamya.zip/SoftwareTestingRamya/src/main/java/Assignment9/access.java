package Assignment9;

public class access {
    public static void main(String[] args){
        ClassA classintititom = new ClassA();
        classintititom.u = 24;
        classintititom.v = 56;
        classintititom.sum();

    }
}
