package Assignment9;

public class ClassA {
     static int u;
    static int v;
   static void sum(){
        System.out.println(u+v);
    }

}
