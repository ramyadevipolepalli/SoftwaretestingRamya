package classass3;

public class displayfirst10naturalnumbers {
    public static void main(String[] args){
        int count=1;
        while(count<=10)
        {
            System.out.println(count);
            count++;
        }
    }
}
