package classass3;

public class first10naturaldesc {
    public static void main(String[] args){
        int count=10;
        while(count>0)
        {
            System.out.println(count);
            count--;
        }
    }
}
