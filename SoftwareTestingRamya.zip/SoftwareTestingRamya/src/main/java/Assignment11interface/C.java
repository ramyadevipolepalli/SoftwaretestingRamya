package Assignment11interface;

public interface C {
    int a = 456,b = 567;
    void ma();
    void mb();
}
