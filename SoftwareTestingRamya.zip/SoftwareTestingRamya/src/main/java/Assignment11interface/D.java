package Assignment11interface;

public interface D {
    int c = 678,d = 956;
    void mc();
    void md();
}
