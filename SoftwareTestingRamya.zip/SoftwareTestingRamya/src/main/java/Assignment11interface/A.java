package Assignment11interface;

public interface A {
    int a = 45,b = 56;
    void m1();
  void m2();

    void Sum();

}
