package Classassignment;

public class SINGLEDIMENTIONALARRAY {

        public static void main(String args[]){
            Object a[]=new Object[5];
            a[0]=10;
            a[1]=20.5;
            a[2]=45;
            a[3]=67;
            a[4]=79;

                for (int i = 0; i < a.length; i++)
                {
                    System.out.println(a[i]);
            }
}
}
