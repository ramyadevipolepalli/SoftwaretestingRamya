package Classassignment;

public class singledimentionalforeach {
    public static void main(String[] args) {
        int a[] = {45, 67, 87, 5680, 7867};
        for (int i : a) {
            System.out.println(i);
        }
    }
    }
