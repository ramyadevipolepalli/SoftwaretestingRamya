package Assignment7;

public class overloading {
    public static void main(String[] args){
        Sum S = new Sum();
        System.out.println(S.sum(67,89));
        System.out.println(S.sum(65.87,89.76));
    }
}
