package Assignment7;

public class Sum {
    int sum(int a,int b)
    {
        return a+b;
    }
    double sum(double c,double d)
    {
        return c+d;
    }
}
