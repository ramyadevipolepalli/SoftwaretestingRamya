package Assignment10inheritance;

public class classa {
    static int a=1,b=2;
  static   void m1(){
        System.out.println("acessm1");
    }
  static   void m2(){
        System.out.println("acessm2");
    }
}
