package Assignment10inheritance;

public class test extends classb{
    public static void main(String[] args){
        System.out.println(a);
        System.out.println(b);
        System.out.println(c);
        System.out.println(d);

       m1();
        m2();
        m3();
      m4();
    }

}
