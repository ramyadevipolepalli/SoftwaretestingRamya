package Assignment10inheritance;

public class testab extends clasa {
    public static void main(String[] args) {
        System.out.println(a);
        System.out.println(b);

       m1();
        m2();

    }
}
