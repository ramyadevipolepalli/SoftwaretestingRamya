package Assignment10inheritance;

public class clasb extends clasa {
    static int c=3,d=4;
   static void m3(){
        System.out.println("acessm3");
    }
   static void m4(){
        System.out.println("acessm4");
    }
}
