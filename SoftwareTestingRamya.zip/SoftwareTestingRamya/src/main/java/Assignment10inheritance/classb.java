package Assignment10inheritance;

public class classb extends classa{
   static int c=3,d=4;
  static   void m3(){
        System.out.println("acessm3");
    }
  static   void m4(){
        System.out.println("acessm4");
    }
  static   void m1(){
        System.out.println("seewhathappens");
    }
  static   void m2(){
        System.out.println("letussee");
    }
}
