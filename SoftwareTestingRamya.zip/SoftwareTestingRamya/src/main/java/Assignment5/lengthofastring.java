package Assignment5;

import java.util.Scanner;

public class lengthofastring {
    public static void main(String[] args) {
        String input;
        System.out.println("Enter a String");
        Scanner scan = new Scanner(System.in);
        input = scan.next();
        System.out.println(input.length());
}}
