package Assignment5;

import java.util.Scanner;

public class concatinatetwostrings {
    public static void main(String[] args){
        String inputa;
        String Output;
        System.out.println("Enter  String1");
        Scanner scan = new Scanner(System.in);
        inputa = scan.next();
        String inputb;
        System.out.println("Enter  String2");
        Scanner sca = new Scanner(System.in);
        inputb = sca.next();
        Output = inputa.concat(inputb);
        System.out.println(Output);

    }
}

